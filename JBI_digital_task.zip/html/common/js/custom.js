$(window).on("scroll", function () {
  if ($(window).scrollTop() > 50) {
    $("header").addClass("active");
  } else {

    $("header").removeClass("active");
  }
});




$(function () {
  $('.humber_icon').click(function () {
    $('.humber_icon').toggleClass('active')
    $(".menuOverlay").slideToggle("slow");
  });
});


$(function () {
  $('footer .inner h5').click(function () {
    $(this).next("ul").slideToggle("slow");
  });
});

$(function () {
  $('.multiple-items').slick({
    infinite: true,
    slidesToShow: 5,
    slidesToScroll: 5,
    responsive: [
      {
        breakpoint: 700,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2,
        }
      }
    ]
  });
});




$(function () {
  $('.owl-carousel').owlCarousel({
    loop: true,
    margin: 30,
    autoplay: true,
    autoplayTimeout: 1520,
    smartSpeed: 1500,
    autoWidth: true,
    autoplayHoverPause: true,
    nav: true,
    responsive: {
      0: {
        items: 1
      },
      600: {
        items: 3
      },
      1000: {
        items: 5
      }
    }
  })
});